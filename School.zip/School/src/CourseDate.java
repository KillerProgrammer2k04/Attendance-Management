import java.util.Date;

public class CourseDate {
    private int courseDateId;
    private Date date;
    private Course course;

    public CourseDate(int courseDateId, Date date, Course course) {
        this.courseDateId = courseDateId;
        this.date = date;
        this.course = course;
    }

    // Getters and setters
    public int getCourseDateId() { return courseDateId; }
    public void setCourseDateId(int courseDateId) { this.courseDateId = courseDateId; }
    public Date getDate() { return date; }
    public void setDate(Date date) { this.date = date; }
    public Course getCourse() { return course; }
    public void setCourse(Course course) { this.course = course; }

    @Override
    public String toString() {
        return "CourseDate{" +
               "courseDateId=" + courseDateId +
               ", date=" + date +
               ", course=" + course.getName() +
               '}';
    }
}
