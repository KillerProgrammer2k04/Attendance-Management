import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		String input;

		while (true) {
			System.out.println("Menu:");
			System.out.println("------------");
			System.out.println("1. Students");
			System.out.println("2. Courses");
			System.out.println("3. Enroll");
			System.out.println("4. Attendance");
			System.out.println("5. Exit");
			System.out.print("Enter your choice (1-5): ");

			input = scanner.nextLine();

			if (input.equals("5")) {
				System.out.println("Exiting the program...");
				break;
			}

			switch (input) {
				case "1":
					StudentMenuHandler.handleStudentsMenu(scanner);
					break;
				case "2":
					CourseMenuHandler.handleCoursesMenu(scanner);
					break;
				case "3":
					EnrollMenuHandler.handleEnrollMenu(scanner);
					break;
				case "4":
					AttendanceMenuHandler.handleAttendanceMenu(scanner);
					break;
				default:
					System.out.println("Invalid choice. Please try again.");
			}
		}

		scanner.close();
	}

}
