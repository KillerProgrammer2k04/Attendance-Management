
import java.util.Date;

public class Attendance {
    private int attendanceId;
    private Student student;
    private Course course;
    private boolean isPresent;
    private Date date;

    public Attendance(int attendanceId, Student student, Course course, boolean isPresent, Date date) {
        this.attendanceId = attendanceId;
        this.student = student;
        this.course = course;
        this.isPresent = isPresent;
        this.date = date;
    }

    // Getters and Setters
    public int getAttendanceId() { return attendanceId; }
    public void setAttendanceId(int attendanceId) { this.attendanceId = attendanceId; }
    public Student getStudent() { return student; }
    public void setStudent(Student student) { this.student = student; }
    public Course getCourse() { return course; }
    public void setCourse(Course course) { this.course = course; }
    public boolean isPresent() { return isPresent; }
    public void setPresent(boolean present) { isPresent = present; }
    public Date getDate() { return date; }
    public void setDate(Date date) { this.date = date; }

    @Override
    public String toString() {
        return "Attendance{" +
               "attendanceId=" + attendanceId +
               ", student=" + student.getFirstName() + " " + student.getLastName() +
               ", course=" + course.getName() +
               ", isPresent=" + isPresent +
               ", date=" + date +
               '}';
    }
}