import java.util.Scanner;

public class StudentMenuHandler {

    private static DatabaseUtils dbUtils = new DatabaseUtils();

    public static void handleStudentsMenu(Scanner scanner) {
        System.out.println("1. Students Menu:");
        System.out.println("a. Add");
        System.out.println("b. Delete");
        System.out.println("c. List");
        System.out.println("d. Find");
        System.out.print("Enter your choice: ");

        String choice = scanner.nextLine();
        switch (choice) {
            case "a":
                addStudent(scanner);
                break;
            case "b":
                deleteStudent(scanner);
                break;
            case "c":
                listStudents();
                break;
            case "d":
                findStudent(scanner);
                break;
            default:
                System.out.println("Invalid choice in Students menu.");
        }
    }

    public static void addStudent(Scanner scanner) {
        System.out.println("Adding student...");
        System.out.print("Enter first name: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter last name: ");
        String lastName = scanner.nextLine();
        System.out.print("Enter email: ");
        String email = scanner.nextLine();
        System.out.print("Enter phone: ");
        String phone = scanner.nextLine();
        System.out.print("Enter address: ");
        String address = scanner.nextLine();

        Student newStudent = new Student(0, firstName, lastName, email, phone, address);
        dbUtils.addStudent(newStudent);
    }

    public static void deleteStudent(Scanner scanner) {
        System.out.println("Deleting student...");
        System.out.print("Enter student ID: ");
        int studentIdToDelete = Integer.parseInt(scanner.nextLine());
        dbUtils.deleteStudent(studentIdToDelete);
    }

    public static void listStudents() {
        System.out.println("Listing students...");
        for (Student student : dbUtils.listStudents()) {
            System.out.println(student);
        }
    }

    public static void findStudent(Scanner scanner) {
        System.out.println("Finding student...");
        System.out.print("Enter student ID: ");
        int studentIdToFind = Integer.parseInt(scanner.nextLine());
        Student foundStudent = dbUtils.findStudentById(studentIdToFind);
        if (foundStudent != null) {
            System.out.println(foundStudent);
        } else {
            System.out.println("Student not found.");
        }
    }
}

