import java.util.Scanner;

public class EnrollMenuHandler {

    private static DatabaseUtils dbUtils = new DatabaseUtils();

    public static void handleEnrollMenu(Scanner scanner) {
        System.out.println("3. Enroll Menu:");
        System.out.println("a. Add");
        System.out.println("b. Delete");
        System.out.println("c. List");
        System.out.println("d. Find");
        System.out.print("Enter your choice: ");

        String choice = scanner.nextLine();
        switch (choice) {
            case "a":
                addEnrollment(scanner);
                break;
            case "b":
                deleteEnrollment(scanner);
                break;
            case "c":
                listEnrollments();
                break;
            case "d":
                findEnrollment(scanner);
                break;
            default:
                System.out.println("Invalid choice in Enroll menu.");
        }
    }

    private static void addEnrollment(Scanner scanner) {
        System.out.println("Adding enrollment...");
        System.out.print("Enter student ID: ");
        int studentId = Integer.parseInt(scanner.nextLine());
        System.out.print("Enter course ID: ");
        int courseId = Integer.parseInt(scanner.nextLine());
        System.out.print("Enter enrollment date (YYYY-MM-DD): ");
        String date = scanner.nextLine();

        Student student = dbUtils.findStudentById(studentId);
        Course course = dbUtils.findCourseById(courseId);

        if (student == null) {
            System.out.println("Student not found.");
            return;
        }
        if (course == null) {
            System.out.println("Course not found.");
            return;
        }

        Enrollment newEnrollment = new Enrollment(student, course, java.sql.Date.valueOf(date));
        dbUtils.addEnrollment(newEnrollment);
    }

    private static void deleteEnrollment(Scanner scanner) {
        System.out.println("Deleting enrollment...");
        System.out.print("Enter student ID: ");
        int studentId = Integer.parseInt(scanner.nextLine());
        System.out.print("Enter course ID: ");
        int courseId = Integer.parseInt(scanner.nextLine());

        dbUtils.deleteEnrollment(studentId, courseId);
    }

    private static void listEnrollments() {
        System.out.println("Listing enrollments...");
        for (Enrollment enrollment : dbUtils.listEnrollments()) {
            System.out.println(enrollment);
        }
    }

    private static void findEnrollment(Scanner scanner) {
        System.out.println("Finding enrollment...");
        System.out.print("Enter student ID: ");
        int studentId = Integer.parseInt(scanner.nextLine());
        System.out.print("Enter course ID: ");
        int courseId = Integer.parseInt(scanner.nextLine());

        Enrollment enrollment = dbUtils.findEnrollment(studentId, courseId);
        if (enrollment != null) {
            System.out.println(enrollment);
        } else {
            System.out.println("Enrollment not found.");
        }
    }
}

