import java.util.Scanner;

public class AttendanceMenuHandler {

    private static DatabaseUtils dbUtils = new DatabaseUtils();

    public static void handleAttendanceMenu(Scanner scanner) {
        System.out.println("4. Attendance Menu:");
        System.out.println("a. Add");
        System.out.println("b. Delete");
        System.out.println("c. List");
        System.out.println("d. Find");
        System.out.println("e. Statistics");
        System.out.print("Enter your choice: ");

        String choice = scanner.nextLine();
        switch (choice) {
            case "a":
                addAttendance(scanner);
                break;
            case "b":
                deleteAttendance(scanner);
                break;
            case "c":
                listAttendances();
                break;
            case "d":
                findAttendance(scanner);
                break;
            case "e":
                reportStatistics(scanner);
                break;
            default:
                System.out.println("Invalid choice in Attendance menu.");
        }
    }

    private static void addAttendance(Scanner scanner) {
        System.out.println("Adding attendance...");
        System.out.print("Enter student ID: ");
        int studentId = Integer.parseInt(scanner.nextLine());
        System.out.print("Enter course ID: ");
        int courseId = Integer.parseInt(scanner.nextLine());
        System.out.print("Enter attendance date (YYYY-MM-DD): ");
        String date = scanner.nextLine();
        System.out.print("Is the student present? (true/false): ");
        boolean isPresent = Boolean.parseBoolean(scanner.nextLine());

        Student student = dbUtils.findStudentById(studentId);
        Course course = dbUtils.findCourseById(courseId);

        if (student == null) {
            System.out.println("Student not found.");
            return;
        }
        if (course == null) {
            System.out.println("Course not found.");
            return;
        }

        Attendance newAttendance = new Attendance(0, student, course, isPresent, java.sql.Date.valueOf(date));
        dbUtils.addAttendance(newAttendance);
    }

    private static void deleteAttendance(Scanner scanner) {
        System.out.println("Deleting attendance...");
        System.out.print("Enter attendance ID: ");
        int attendanceIdToDelete = Integer.parseInt(scanner.nextLine());
        dbUtils.deleteAttendance(attendanceIdToDelete);
    }

    private static void listAttendances() {
        System.out.println("Listing attendances...");
        for (Attendance attendance : dbUtils.listAttendances()) {
            System.out.println(attendance);
        }
    }

    private static void findAttendance(Scanner scanner) {
        System.out.println("Finding attendance...");
        System.out.print("Enter attendance ID: ");
        int attendanceIdToFind = Integer.parseInt(scanner.nextLine());
        Attendance foundAttendance = dbUtils.findAttendanceById(attendanceIdToFind);
        if (foundAttendance != null) {
            System.out.println(foundAttendance);
        } else {
            System.out.println("Attendance record not found.");
        }
    }

    private static void reportStatistics(Scanner scanner) {

    }
}

