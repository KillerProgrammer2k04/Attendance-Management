import java.util.Scanner;

public class CourseMenuHandler {

    private static DatabaseUtils dbUtils = new DatabaseUtils();

    public static void handleCoursesMenu(Scanner scanner) {
        System.out.println("2. Courses Menu:");
        System.out.println("a. Add");
        System.out.println("b. Delete");
        System.out.println("c. List");
        System.out.println("d. Find");
        System.out.print("Enter your choice: ");

        String choice = scanner.nextLine();
        switch (choice) {
            case "a":
                addCourse(scanner);
                break;
            case "b":
                deleteCourse(scanner);
                break;
            case "c":
                listCourses();
                break;
            case "d":
                findCourse(scanner);
                break;
            default:
                System.out.println("Invalid choice in Courses menu.");
        }
    }

    private static void addCourse(Scanner scanner) {
        System.out.println("Adding course...");
        System.out.print("Enter course name: ");
        String name = scanner.nextLine();
        System.out.print("Enter course description: ");
        String description = scanner.nextLine();

        Course newCourse = new Course(0, name, description);
        dbUtils.addCourse(newCourse);
    }

    private static void deleteCourse(Scanner scanner) {
        System.out.println("Deleting course...");
        System.out.print("Enter course ID: ");
        int courseIdToDelete = Integer.parseInt(scanner.nextLine());
        dbUtils.deleteCourse(courseIdToDelete);
    }

    private static void listCourses() {
        System.out.println("Listing courses...");
        for (Course course : dbUtils.listCourses()) {
            System.out.println(course);
        }
    }

    private static void findCourse(Scanner scanner) {
        System.out.println("Finding course...");
        System.out.print("Enter course ID: ");
        int courseIdToFind = Integer.parseInt(scanner.nextLine());
        Course foundCourse = dbUtils.findCourseById(courseIdToFind);
        if (foundCourse != null) {
            System.out.println(foundCourse);
        } else {
            System.out.println("Course not found.");
        }
    }
}

