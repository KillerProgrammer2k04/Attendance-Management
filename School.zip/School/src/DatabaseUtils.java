import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DatabaseUtils {
    private static final String DATABASE_URL = "jdbc:mariadb://localhost:3306/schooldb";
    private static final String DATABASE_USER = "root";
    private static final String DATABASE_PASSWORD = "16419";

    // establish a database connection
    public Connection connect() {
        try {
            return DriverManager.getConnection(DATABASE_URL, DATABASE_USER, DATABASE_PASSWORD);
        } catch (SQLException e) {
            System.out.println("Connection Failed: " + e.getMessage());
            return null;
        }
    }

    // execute a query (read data)
    public void executeQuery(String query) {
        try (Connection conn = connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                // Assume you're reading a string from the first column in your result set
                System.out.println(rs.getString(1));
            }
        } catch (SQLException e) {
            System.out.println("Query Execution Failed: " + e.getMessage());
        }
    }

    //  execute an update (write data)
    public void executeUpdate(String query) {
        try (Connection conn = connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            int result = stmt.executeUpdate();
            System.out.println("Rows affected: " + result);
        } catch (SQLException e) {
            System.out.println("Update Failed: " + e.getMessage());
        }
    }

    // add a student
    public void addStudent(Student student) {
        String query = "INSERT INTO Students (firstName, lastName, email, phone, address) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, student.getFirstName());
            stmt.setString(2, student.getLastName());
            stmt.setString(3, student.getEmail());
            stmt.setString(4, student.getPhone());
            stmt.setString(5, student.getAddress());

            int result = stmt.executeUpdate();
            System.out.println("Rows affected: " + result);
        } catch (SQLException e) {
            System.out.println("Insert Failed: " + e.getMessage());
        }
    }

    // delete a student by ID
    public void deleteStudent(int studentId) {
        String query = "DELETE FROM Students WHERE id = ?";
        try (Connection conn = connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, studentId);

            int result = stmt.executeUpdate();
            System.out.println("Rows affected: " + result);
        } catch (SQLException e) {
            System.out.println("Delete Failed: " + e.getMessage());
        }
    }

    // list all students
    public List<Student> listStudents() {
        List<Student> students = new ArrayList<>();
        String query = "SELECT * FROM Students";
        try (Connection conn = connect();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Student student = new Student(
                        rs.getInt("id"),
                        rs.getString("firstName"),
                        rs.getString("lastName"),
                        rs.getString("email"),
                        rs.getString("phone"),
                        rs.getString("address")
                );
                students.add(student);
            }
        } catch (SQLException e) {
            System.out.println("Query Failed: " + e.getMessage());
        }
        return students;
    }

    // find a student by ID
    public Student findStudentById(int studentId) {
        String query = "SELECT * FROM Students WHERE id = ?";
        try (Connection conn = connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, studentId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new Student(
                        rs.getInt("id"),
                        rs.getString("firstName"),
                        rs.getString("lastName"),
                        rs.getString("email"),
                        rs.getString("phone"),
                        rs.getString("address")
                );
            }
        } catch (SQLException e) {
            System.out.println("Query Failed: " + e.getMessage());
        }
        return null;
    }

    // Method to add a course
    public void addCourse(Course course) {
        String query = "INSERT INTO Courses (name, description) VALUES (?, ?)";
        try (Connection conn = connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, course.getName());
            stmt.setString(2, course.getDescription());

            int result = stmt.executeUpdate();
            System.out.println("Rows affected: " + result);
        } catch (SQLException e) {
            System.out.println("Insert Failed: " + e.getMessage());
        }
    }

    // Method to delete a course by ID
    public void deleteCourse(int courseId) {
        String query = "DELETE FROM Courses WHERE courseId = ?";
        try (Connection conn = connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, courseId);

            int result = stmt.executeUpdate();
            System.out.println("Rows affected: " + result);
        } catch (SQLException e) {
            System.out.println("Delete Failed: " + e.getMessage());
        }
    }

    // Method to list all courses
    public List<Course> listCourses() {
        List<Course> courses = new ArrayList<>();
        String query = "SELECT * FROM Courses";
        try (Connection conn = connect();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Course course = new Course(
                        rs.getInt("courseId"),
                        rs.getString("name"),
                        rs.getString("description")
                );
                courses.add(course);
            }
        } catch (SQLException e) {
            System.out.println("Query Failed: " + e.getMessage());
        }
        return courses;
    }

    // Method to find a course by ID
    public Course findCourseById(int courseId) {
        String query = "SELECT * FROM Courses WHERE courseId = ?";
        try (Connection conn = connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, courseId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new Course(
                        rs.getInt("courseId"),
                        rs.getString("name"),
                        rs.getString("description")
                );
            }
        } catch (SQLException e) {
            System.out.println("Query Failed: " + e.getMessage());
        }
        return null;
    }

    // Method to add an enrollment
    public void addEnrollment(Enrollment enrollment) {
        String query = "INSERT INTO Enrollments (studentId, courseId, enrollmentDate) VALUES (?, ?, ?)";
        try (Connection conn = connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, enrollment.getStudent().getId());
            stmt.setInt(2, enrollment.getCourse().getCourseId());
            stmt.setDate(3, new java.sql.Date(enrollment.getEnrollmentDate().getTime()));

            int result = stmt.executeUpdate();
            System.out.println("Rows affected: " + result);
        } catch (SQLException e) {
            System.out.println("Insert Failed: " + e.getMessage());
        }
    }

    // Method to delete an enrollment
    public void deleteEnrollment(int studentId, int courseId) {
        String query = "DELETE FROM Enrollments WHERE studentId = ? AND courseId = ?";
        try (Connection conn = connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, studentId);
            stmt.setInt(2, courseId);

            int result = stmt.executeUpdate();
            System.out.println("Rows affected: " + result);
        } catch (SQLException e) {
            System.out.println("Delete Failed: " + e.getMessage());
        }
    }

    // Method to list all enrollments
    public List<Enrollment> listEnrollments() {
        List<Enrollment> enrollments = new ArrayList<>();
        String query = "SELECT e.studentId, e.courseId, e.enrollmentDate, s.firstName, s.lastName, c.name " +
                "FROM Enrollments e " +
                "JOIN Students s ON e.studentId = s.id " +
                "JOIN Courses c ON e.courseId = c.courseId";
        try (Connection conn = connect();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Student student = new Student(
                        rs.getInt("studentId"),
                        rs.getString("firstName"),
                        rs.getString("lastName"),
                        null, // email not selected
                        null, // phone not selected
                        null  // address not selected
                );
                Course course = new Course(
                        rs.getInt("courseId"),
                        rs.getString("name"),
                        null // description not selected
                );
                Enrollment enrollment = new Enrollment(
                        student,
                        course,
                        rs.getDate("enrollmentDate")
                );
                enrollments.add(enrollment);
            }
        } catch (SQLException e) {
            System.out.println("Query Failed: " + e.getMessage());
        }
        return enrollments;
    }

    // Method to find an enrollment by student ID and course ID
    public Enrollment findEnrollment(int studentId, int courseId) {
        String query = "SELECT e.studentId, e.courseId, e.enrollmentDate, s.firstName, s.lastName, c.name " +
                "FROM Enrollments e " +
                "JOIN Students s ON e.studentId = s.id " +
                "JOIN Courses c ON e.courseId = c.courseId " +
                "WHERE e.studentId = ? AND e.courseId = ?";
        try (Connection conn = connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, studentId);
            stmt.setInt(2, courseId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Student student = new Student(
                        rs.getInt("studentId"),
                        rs.getString("firstName"),
                        rs.getString("lastName"),
                        null, // email not selected
                        null, // phone not selected
                        null  // address not selected
                );
                Course course = new Course(
                        rs.getInt("courseId"),
                        rs.getString("name"),
                        null // description not selected
                );
                return new Enrollment(
                        student,
                        course,
                        rs.getDate("enrollmentDate")
                );
            }
        } catch (SQLException e) {
            System.out.println("Query Failed: " + e.getMessage());
        }
        return null;
    }

    // Method to add attendance
    public void addAttendance(Attendance attendance) {
        String query = "INSERT INTO Attendances (studentId, courseId, isPresent, date) VALUES (?, ?, ?, ?)";
        try (Connection conn = connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, attendance.getStudent().getId());
            stmt.setInt(2, attendance.getCourse().getCourseId());
            stmt.setBoolean(3, attendance.isPresent());
            stmt.setDate(4, new java.sql.Date(attendance.getDate().getTime()));

            int result = stmt.executeUpdate();
            System.out.println("Rows affected: " + result);
        } catch (SQLException e) {
            System.out.println("Insert Failed: " + e.getMessage());
        }
    }

    // Method to delete attendance by ID
    public void deleteAttendance(int attendanceId) {
        String query = "DELETE FROM Attendances WHERE attendanceId = ?";
        try (Connection conn = connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, attendanceId);

            int result = stmt.executeUpdate();
            System.out.println("Rows affected: " + result);
        } catch (SQLException e) {
            System.out.println("Delete Failed: " + e.getMessage());
        }
    }

    // Method to list all attendance records
    public List<Attendance> listAttendances() {
        List<Attendance> attendances = new ArrayList<>();
        String query = "SELECT a.attendanceId, a.studentId, a.courseId, a.isPresent, a.date, s.firstName, s.lastName, c.name " +
                "FROM Attendances a " +
                "JOIN Students s ON a.studentId = s.id " +
                "JOIN Courses c ON a.courseId = c.courseId";
        try (Connection conn = connect();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Student student = new Student(
                        rs.getInt("studentId"),
                        rs.getString("firstName"),
                        rs.getString("lastName"),
                        null, // email not selected
                        null, // phone not selected
                        null  // address not selected
                );
                Course course = new Course(
                        rs.getInt("courseId"),
                        rs.getString("name"),
                        null // description not selected
                );
                Attendance attendance = new Attendance(
                        rs.getInt("attendanceId"),
                        student,
                        course,
                        rs.getBoolean("isPresent"),
                        rs.getDate("date")
                );
                attendances.add(attendance);
            }
        } catch (SQLException e) {
            System.out.println("Query Failed: " + e.getMessage());
        }
        return attendances;
    }

    // Method to find an attendance record by ID
    public Attendance findAttendanceById(int attendanceId) {
        String query = "SELECT a.attendanceId, a.studentId, a.courseId, a.isPresent, a.date, s.firstName, s.lastName, c.name " +
                "FROM Attendances a " +
                "JOIN Students s ON a.studentId = s.id " +
                "JOIN Courses c ON a.courseId = c.courseId " +
                "WHERE a.attendanceId = ?";
        try (Connection conn = connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, attendanceId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Student student = new Student(
                        rs.getInt("studentId"),
                        rs.getString("firstName"),
                        rs.getString("lastName"),
                        null, // email not selected
                        null, // phone not selected
                        null  // address not selected
                );
                Course course = new Course(
                        rs.getInt("courseId"),
                        rs.getString("name"),
                        null // description not selected
                );
                return new Attendance(
                        rs.getInt("attendanceId"),
                        student,
                        course,
                        rs.getBoolean("isPresent"),
                        rs.getDate("date")
                );
            }
        } catch (SQLException e) {
            System.out.println("Query Failed: " + e.getMessage());
        }
        return null;
    }
}