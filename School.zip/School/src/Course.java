

import java.util.ArrayList;
import java.util.List;


public class Course {
    private int courseId;
    private String name;
    private String description;
    private List<Enrollment> enrollments;

    public Course(int courseId, String name, String description) {
        this.courseId = courseId;
        this.name = name;
        this.description = description;
        this.enrollments = new ArrayList<>();
    }

    // Add enrollment
    public void addEnrollment(Enrollment enrollment) {
        enrollments.add(enrollment);
    }

    // Remove enrollment
    public void removeEnrollment(Enrollment enrollment) {
        enrollments.remove(enrollment);
    }

    // Getters and Setters
    public int getCourseId() { return courseId; }
    public void setCourseId(int courseId) { this.courseId = courseId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public List<Enrollment> getEnrollments() { return new ArrayList<>(enrollments); }

    @Override
    public String toString() {
        return "Course{" +
               "courseId=" + courseId +
               ", name='" + name + '\'' +
               ", description='" + description + '\'' +
               ", enrollments=" + enrollments.size() +
               '}';
    }
}