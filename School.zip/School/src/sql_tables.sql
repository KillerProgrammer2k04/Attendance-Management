-- Use or create the database
CREATE DATABASE IF NOT EXISTS SchoolDB;

USE SchoolDB;

-- Table for storing students
CREATE TABLE IF NOT EXISTS Students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    firstName VARCHAR(100) NOT NULL,
    lastName VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(15) NOT NULL,
    address VARCHAR(255) NOT NULL
);

-- Table for storing courses
CREATE TABLE IF NOT EXISTS Courses (
    courseId INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT NOT NULL
);

-- Table for managing student enrollments in courses
CREATE TABLE IF NOT EXISTS Enrollments (
    studentId INT NOT NULL,
    courseId INT NOT NULL,
    enrollmentDate DATE NOT NULL,
    PRIMARY KEY (studentId, courseId),
    CONSTRAINT fk_enrollment_studentId FOREIGN KEY (studentId) REFERENCES Students(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_enrollment_courseId FOREIGN KEY (courseId) REFERENCES Courses(courseId)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- Table for storing course dates
CREATE TABLE IF NOT EXISTS CourseDates (
    courseDateId INT AUTO_INCREMENT PRIMARY KEY,
    date DATE NOT NULL,
    courseId INT NOT NULL,
    CONSTRAINT fk_courseId FOREIGN KEY (courseId) REFERENCES Courses(courseId)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- Table for storing attendance records
CREATE TABLE IF NOT EXISTS Attendances (
    attendanceId INT AUTO_INCREMENT PRIMARY KEY,
    studentId INT NOT NULL,
    courseId INT NOT NULL,
    isPresent BOOLEAN NOT NULL,
    date DATE NOT NULL,
    CONSTRAINT fk_attendance_studentId FOREIGN KEY (studentId) REFERENCES Students(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_attendance_courseId FOREIGN KEY (courseId) REFERENCES Courses(courseId)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_attendance_enrollment FOREIGN KEY (studentId, courseId) REFERENCES Enrollments(studentId, courseId)
        ON DELETE CASCADE ON UPDATE CASCADE
);

